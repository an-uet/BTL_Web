module.exports = {
    HOST: "localhost",
    PORT: 27017,
    DB: "citizenV",
  };