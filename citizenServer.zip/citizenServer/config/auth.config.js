module.exports = {
    secret: "hello, today is a happy day",
  };