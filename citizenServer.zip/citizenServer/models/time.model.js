/*const mongoose = require("mongoose");

const workingTime = mongoose.model(
  "workingTime",
  new mongoose.Schema({
    start: Date,
    finish: Date
  })
);

module.exports = workingTime;*/