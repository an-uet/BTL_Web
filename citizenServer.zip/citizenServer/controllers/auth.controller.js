const config = require("../config/auth.config")
const db = require("../models");
const User = db.user;
const Role = db.role;

var jwt = require("jsonwebtoken");
var bcrypt = require("bcryptjs");

//signup A1

exports.signupA1 = (req, res) => {

  const user = new User({
    username: req.body.username,
    password: bcrypt.hashSync(req.body.password, 8),

  });

  user.save((err, user) => {
    if (err) {
      res.status(500).send({ message: err });
      return;
    }
    
    Role.findOne({ name: "A1" }, (err, role) => {
      if (err) {
        res.status(500).send({ message: err });
        return;
      }

      user.role = role._id;
      user.save(err => {
        if (err) {
          res.status(500).send({ message: err });
          return;
        }

        res.send({ message: "User was registered successfully!" });
      });
    });

  });
};



//signup user: A2
exports.signupA2 = (req, res) => {
  const user = new User({
    username: req.body.username,
    password: bcrypt.hashSync(req.body.password, 8),
    createBy: 'A1',
    timeStart: req.body.timeStart,
    timeFinish: req.body.timeFinish

  });

  user.save((err, user) => {
    if (err) {
      res.status(500).send({ message: err });
      return;
    }
    /*

    if (req.body.roles) {
      Role.find(
        {
          name: { $in: req.body.roles }
        },
        (err, roles) => {
          if (err) {
            res.status(500).send({ message: err });
            return;
          }

          user.roles = roles.map(role => role._id);
          user.save(err => {
            if (err) {
              res.status(500).send({ message: err });
              return;
            }

            res.send({ message: "User was registered successfully!" });
          });
        }
      );
    } */

    Role.findOne({ name: "A2" }, (err, role) => {
      if (err) {
        res.status(500).send({ message: err });
        return;
      }

      user.role = role._id;
      user.save(err => {
        if (err) {
          res.status(500).send({ message: err });
          return;
        }

        res.send({ message: "User was registered successfully!" });
      });
    });

  });
};

//signup user: A3
exports.signupA3 = (req, res) => {
  const user = new User({
    username: req.body.username,
    password: bcrypt.hashSync(req.body.password, 8),
    createBy: 'A2',
    timeStart: req.body.timeStart,
    timeFinish: req.body.timeFinish
  });

  user.save((err, user) => {
    if (err) {
      res.status(500).send({ message: err });
      return;
    }

    Role.findOne({ name: "A3" }, (err, role) => {
      if (err) {
        res.status(500).send({ message: err });
        return;
      }

      user.role = role._id;
      user.save(err => {
        if (err) {
          res.status(500).send({ message: err });
          return;
        }

        res.send({ message: "User was registered successfully!" });
      });
    });

  });
};


//signup user: B1
exports.signupB1 = (req, res) => {
  const user = new User({
    username: req.body.username,
    password: bcrypt.hashSync(req.body.password, 8),
    createBy: 'A3',
    timeStart: req.body.timeStart,
    timeFinish: req.body.timeFinish
  });

  user.save((err, user) => {
    if (err) {
      res.status(500).send({ message: err });
      return;
    }

    Role.findOne({ name: "B1" }, (err, role) => {
      if (err) {
        res.status(500).send({ message: err });
        return;
      }

      user.role = role._id;
      user.save(err => {
        if (err) {
          res.status(500).send({ message: err });
          return;
        }

        res.send({ message: "User was registered successfully!" });
      });
    });

  });
};

//signup user: B2
exports.signupB2 = (req, res) => {
  const user = new User({
    username: req.body.username,
    password: bcrypt.hashSync(req.body.password, 8),
    createBy: 'B1',
    timeStart: req.body.timeStart,
    timeFinish: req.body.timeFinish
  });

  user.save((err, user) => {
    if (err) {
      res.status(500).send({ message: err });
      return;
    }

    Role.findOne({ name: "B2" }, (err, role) => {
      if (err) {
        res.status(500).send({ message: err });
        return;
      }

      user.role = role._id;
      user.save(err => {
        if (err) {
          res.status(500).send({ message: err });
          return;
        }

        res.send({ message: "User was registered successfully!" });
      });
    });

  });
};


//signin
exports.signin = (req, res) => {
  User.findOne({
    username: req.body.username
  })
    .populate("role")
    .exec((err, user) => {
      if (err) {
        res.status(500).send({ message: err });
        return;
      }

      if (!user) {
        return res.status(404).send({ message: "User Not found." });
      }

      var passwordIsValid = bcrypt.compareSync(
        req.body.password,
        user.password
      );

      if (!passwordIsValid) {
        return res.status(401).send({
          accessToken: null,
          message: "Invalid Password!"
        });
      }

      var token = jwt.sign({ id: user.id }, config.secret, {
        expiresIn: 86400 // 24 hours
      });

      var authorities = '';

      
      authorities = user.role.name;
      res.status(200).send({
        id: user._id,
        username: user.username,
        role: authorities,
        createBy: user.createBy,
        timeStart: user.timeStart,
        timeFinish: user.timeFinish,
        accessToken: token
      });
    });
};
