//get list of user.
 exports.getA2 = (req, res) => {
    res.status(200).send("A2 Content.");
  };
  
  exports.getA3 = (req, res) => {
    res.status(200).send("A3 Content.");
  };
  
  exports.getB1 = (req, res) => {
    res.status(200).send("B1 Content.");
  };
  
  exports.getB2 = (req, res) => {
    res.status(200).send("B2 Content.");
  };
  