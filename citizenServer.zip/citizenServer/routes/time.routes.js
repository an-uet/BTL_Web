const db = require("../models");
const workingTime = db.city;
const { authJwt } = require("../middlewares");


//kiem tra xem con thoi han dang ki khong

checkWorkingTime = (req, res, next) => {
    var date_now = new Date();
    
    
};